
foo <- function(x) return(x %% 1)

library(testthat)

test_file("C:/Users/Milan/Desktop/EdinbR/testthat_file.R")
