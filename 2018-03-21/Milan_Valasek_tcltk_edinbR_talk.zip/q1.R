
### q1
tt2 <- tktoplevel()
tkwm.title(tt2, "Question One")
question <-"What... is your name?"

### test not run
entry.name <- tclVar("")
### run not test

OnOK0 <- function()  {
  q1 <<- question
  q1_ans <<- tclvalue(entry.name)
  tkdestroy(tt2)
}

OK.but <- tkbutton(tt2, text = "Next", command = OnOK0)

tkgrid(tklabel(tt2, text = question),
       columnspan = 4, padx = 10, pady = 10)
tkgrid(tkentry(tt2, width = "20", textvariable = entry.name), padx = 10, pady = 10)
tkgrid(OK.but, columnspan = 4, pady = 10)
Sys.sleep(0.05)
if (test.run) OnOK0() else finalise.window(tt2)
