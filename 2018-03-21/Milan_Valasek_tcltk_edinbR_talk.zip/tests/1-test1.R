
context("Testing the Holy Grail app output")

test_that("Output is correct", expect_equal(output, out_ref))
