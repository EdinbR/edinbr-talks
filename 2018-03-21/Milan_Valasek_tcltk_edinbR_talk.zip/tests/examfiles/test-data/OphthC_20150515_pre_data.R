
# OphthC before discussion --------------------------------------------------
# Ceses - mark per case


# win 1 --------------------------------------------------------------------

rbValue <- tclVar("Preliminary")


# win 2 -------------------------------------------------------------------

specialty <- "Disc2Spec2"
mock_date <- "20150515"
checked_components <- c(0, 0, 0, 1, 0)
for (i in 1:length(comps_test))
  assign(paste0("component", i), tclVar(checked_components[i]))
exam_date <- tclVar(mock_date)
n_cand <- tclVar("20")


# win 3 -------------------------------------------------------------------

n_exemptCases <- tclVar("3")
default_dom_Cases <- tclVar("None")
number_Cases <- tclVar("5")
rbValue5 <- tclVar("Mark/Case")


# win 4 -------------------------------------------------------------------

mock_namesCases <- c("Case 01", "Case 02", "Case 03", "Case 04", "Case 05")
for (i in 1:length(mock_namesCases))
  assign(paste0("case_name", i), tclVar(mock_namesCases[i]))
