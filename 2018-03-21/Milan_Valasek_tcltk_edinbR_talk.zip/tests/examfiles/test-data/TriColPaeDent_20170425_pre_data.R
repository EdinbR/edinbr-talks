
# TriColPaeDent before discussion -------------------------------------------
# SBA paper
# Documented & Simulated Cases
# Clinical Governance


# win 1 --------------------------------------------------------------------

rbValue <- tclVar("Preliminary")


# win 2 -------------------------------------------------------------------

specialty <- "Disc1Spec10"
mock_date <- "20170425"
checked_components <- c(1, 0, 0, 1, 0)
for (i in 1:length(comps_test))
  assign(paste0("component", i), tclVar(checked_components[i]))
exam_date <- tclVar(mock_date)
n_cand = tclVar("30")

# details ----------------------------------------------------------------

n_SBA <- tclVar("180")
n_EMI <- tclVar("0")
n_exemptSBA = tclVar("")
n_exemptDocCases <- tclVar("1, 17:19; 3; 28:26")
n_exemptSimCases <- tclVar("")
n_exemptClinGov <- tclVar("2:7, 15")

