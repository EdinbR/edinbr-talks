

# SEM Part 1 post discussion ----------------------------------------------------
# 2 SBA papers
# checklist OSCES
# Orals/Vivas

rbValue <- tclVar("Final")

for (i in c(1, 3, 5)) assign(paste0("component",i), tclVar("1"))
for (i in c(2, 4)) assign(paste0("component",i), tclVar("0"))

test_input <- list(
  SBA_EMI = c("J:\\department-files\\r-scripts\\tests\\system-level-tests\\examFiles\\output\\SEM_part-1_General_SBA_EMI_20120212_examDetailsBeforeDiscussion.csv",
              "J:\\department-files\\r-scripts\\tests\\system-level-tests\\examFiles\\output\\SEM_part-1_Spec_SBA_EMI_20120212_examDetailsBeforeDiscussion.csv"),
  OSCE_OSPE = "J:\\department-files\\r-scripts\\tests\\system-level-tests\\examFiles\\output\\SEM_part-1_OSCE_OSPE_20120212_examDetailsBeforeDiscussion.csv",
  Oral_Viva = "J:\\department-files\\r-scripts\\tests\\system-level-tests\\examFiles\\output\\SEM_part-1_Oral_Viva_20120212_examDetailsBeforeDiscussion.csv"
)

number_pass <- list("SBA" = tclVar("21"),
                    "OSCE_OSPE" = tclVar("16"),
                    "Oral_Viva" = tclVar("20"))
number_fail <- list("SBA" = tclVar("12"),
                    "OSCE_OSPE" = tclVar("17"),
                    "Oral_Viva" = tclVar("13"))

rbValue1 <- tclVar("No")
rbValue2 <- tclVar("No")
rbValue3 <- tclVar("Yes")
test_remSBA <- c("3, 4, 177, 178", "1, 2, 87, 88")
removedCases_rb <- tclVar("Yes")

# mark 3rd case for removal
itemsCases <- list(tclVar("0"), tclVar("0"), tclVar("1"), tclVar("0"))
