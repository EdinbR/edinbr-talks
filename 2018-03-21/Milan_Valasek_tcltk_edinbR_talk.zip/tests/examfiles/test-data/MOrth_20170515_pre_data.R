
# MOrth before discussion --------------------------------------------------
# 1 MSA paper
# MOrth specific orals


# win 1 --------------------------------------------------------------------

rbValue <- tclVar("Preliminary")


# win 2 -------------------------------------------------------------------

specialty <- "Disc1Spec6"
mock_date <- "20170515"
checked_components <- c(0, 1, 0, 1, 0)
for (i in 1:length(comps_test))
  assign(paste0("component", i), tclVar(checked_components[i]))
exam_date <- tclVar(mock_date)
n_cand = tclVar("40")

n_exemptMSA <- tclVar("3;5-8,34-33, ")

#  Orals & Cases --------------------------------------------------------
n_exemptCases <- tclVar("6,8")
n_exemptDiag <- tclVar("")
n_exemptOralsComms <- tclVar(" 15")

