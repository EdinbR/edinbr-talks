

# DMIM 20110111 post discussion ----------------------------------------------------
# all components
# 1 SBA paper
# 2 MSA papers
# domain-based OSCES
# domain based Ceses - double marked
# removed some SBAs & Cases
# haven't figured out removing MSAs and OSCEs by feeding code in this way
# so this is coded inside examFiles inside if(test.run) to just tick the
# correct boxes
rbValue <- tclVar("Final")

for (i in 1:(length(comps_test) - 1)) assign(paste0("component",i), tclVar("1"))
component5 <- tclVar("0")

test_input <- list(
  "SBA_EMI" = "J:\\department-files\\r-scripts\\tests\\system-level-tests\\examFiles\\output\\DMIM_SBA_EMI_20110111_examDetailsBeforeDiscussion.csv",
  MSA = c("J:\\department-files\\r-scripts\\tests\\system-level-tests\\examFiles\\output\\DMIM_MSA_20110111_examDetailsBeforeDiscussion.csv",
          "J:\\department-files\\r-scripts\\tests\\system-level-tests\\examFiles\\output\\DMIM_Perio_MSA_20110111_examDetailsBeforeDiscussion.csv"),
  "OSCE_OSPE" = "J:\\department-files\\r-scripts\\tests\\system-level-tests\\examFiles\\output\\DMIM_OSCE_OSPE_20110111_examDetailsBeforeDiscussion.csv",
  Cases = "J:\\department-files\\r-scripts\\tests\\system-level-tests\\examFiles\\output\\DMIM_Cases_20110111_examDetailsBeforeDiscussion.csv"
)

number_pass <- list("SBA_EMI" = tclVar("68"),
                    "MSA" = tclVar("35"),
                    "OSCE_OSPE" = tclVar("30"),
                    "Cases" = tclVar("30"))
number_fail <- list("SBA_EMI" = tclVar("32"),
                    "MSA" = tclVar("15"),
                    "OSCE_OSPE" = tclVar("20"),
                    "Cases" = tclVar("10"))

rbValue1 <- tclVar("Yes")
rbValue2 <- tclVar("No")
rbValue3 <- tclVar("No")
test_remSBA <- c("2, 3, 4, 5, 24, 135, 136")
removedCases_rb <- tclVar("Yes")
# mark 2nd case for removal
itemsCases <- list(tclVar("0"), tclVar("1"), tclVar("0"), tclVar("0"), tclVar("0"))
