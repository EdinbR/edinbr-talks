
# MRD before discussion -------------------------------------------
# general & 3 specialty MSA papers
# Oral components


# win 1 --------------------------------------------------------------------

rbValue <- tclVar("Preliminary")


# win 2 -------------------------------------------------------------------

specialty <- "Disc1Spec7"
mock_date <- "20161126"
checked_components <- c(0, 1, 0, 0, 1)
for (i in 1:length(comps_test))
  assign(paste0("component", i), tclVar(checked_components[i]))
exam_date <- tclVar(mock_date)
n_cand = tclVar("35")

# details ----------------------------------------------------------------

endo_cands <- tclVar("13")
perio_cands <- tclVar("10")
pros_cands <- tclVar("12")
n_exemptMSA = tclVar("102:104;204, 308-309")
n_exemptCases <- tclVar("107, 302-305")
