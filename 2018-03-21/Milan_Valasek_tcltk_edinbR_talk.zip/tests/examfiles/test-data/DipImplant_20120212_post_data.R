

# DipImplant 20120212 post discussion ----------------------------------------------------
# all components
# SBA paper
# checklist-based OSCES
# haven't figured out removing OSCEs by feeding code in this way
# so this is coded inside examFiles inside if(test.run) to just tick the
# correct boxes
rbValue <- tclVar("Final")

for (i in 1:5) assign(paste0("component",i), tclVar("1"))

test_input <- list(
  "SBA_EMI" = "J:\\department-files\\r-scripts\\tests\\system-level-tests\\examFiles\\output\\DipImplant_SBA_EMI_20120212_examDetailsBeforeDiscussion.csv",
  "MSA" = "J:\\department-files\\r-scripts\\tests\\system-level-tests\\examFiles\\output\\DipImplant_MSA_20120212_examDetailsBeforeDiscussion.csv",
  "OSCE_OSPE" = "J:\\department-files\\r-scripts\\tests\\system-level-tests\\examFiles\\output\\DipImplant_OSCE_OSPE_20120212_examDetailsBeforeDiscussion.csv",
  "Cases" = "J:\\department-files\\r-scripts\\tests\\system-level-tests\\examFiles\\output\\DipImplant_Cases_20120212_examDetailsBeforeDiscussion.csv",
  "Oral_Viva" = "J:\\department-files\\r-scripts\\tests\\system-level-tests\\examFiles\\output\\DipImplant_Oral_Viva_20120212_examDetailsBeforeDiscussion.csv"
  )

number_pass <- list("SBA_EMI" = tclVar("25"),
                    "MSA" = tclVar("24"),
                    "OSCE_OSPE" = tclVar("28"),
                    "Cases" = tclVar("25"),
                    "Oral_Viva" = tclVar("20"))
number_fail <- list("SBA_EMI" = tclVar("8"),
                    "MSA" = tclVar("9"),
                    "OSCE_OSPE" = tclVar("5"),
                    "Cases" = tclVar("8"),
                    "Oral_Viva" = tclVar("13"))

rbValue1 <- tclVar("Yes")
rbValue2 <- tclVar("No")
rbValue3 <- tclVar("No")
test_remSBA <- c("3, 4, 177, 178")

removedCases_rb <- tclVar("No")