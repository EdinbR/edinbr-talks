

# MOrth 20170515 post discussion ----------------------------------------------------
# MSA paper
# MOrth Oral components

rbValue <- tclVar("Final")

for (i in c(2, 4)) assign(paste0("component",i), tclVar("1"))
for (i in c(1, 3, 5)) assign(paste0("component",i), tclVar("0"))

test_input <- list(
  MSA = "J:\\department-files\\r-scripts\\tests\\system-level-tests\\examFiles\\output\\MOrth_MSA_20170515_examDetailsBeforeDiscussion.csv",
  Cases = "J:\\department-files\\r-scripts\\tests\\system-level-tests\\examFiles\\output\\MOrth_Cases_20170515_examDetailsBeforeDiscussion.csv",
  Diag = "J:\\department-files\\r-scripts\\tests\\system-level-tests\\examFiles\\output\\MOrth_Diag_20170515_examDetailsBeforeDiscussion.csv",
  Orals_Comms = "J:\\department-files\\r-scripts\\tests\\system-level-tests\\examFiles\\output\\MOrth_Orals_Comms_20170515_examDetailsBeforeDiscussion.csv"
)

number_pass <- list("MSA" = tclVar("30"),
                    "Cases" = tclVar("35"),
                    "Diag" = tclVar("34"),
                    "Orals_Comms" = tclVar("33"))
number_fail <- list("MSA" = tclVar("10"),
                    "Cases" = tclVar("5"),
                    "Diag" = tclVar("6"),
                    "Orals_Comms" = tclVar("7"))

rbValue2 <- tclVar("Yes")
rbValue3 <- tclVar("No")
removedCases_rb <- tclVar("Yes")
# mark 3rd case for removal
itemsCases <- list(tclVar("0"), tclVar("0"), tclVar("1"), tclVar("0"))
