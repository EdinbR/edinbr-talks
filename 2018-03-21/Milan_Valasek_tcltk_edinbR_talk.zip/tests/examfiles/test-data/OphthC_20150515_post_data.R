

# OphthC 20150515 post discussion ----------------------------------------------------
# Ceses - mark per case

is.hard_coded <- FALSE

rbValue <- tclVar("Final")

for (i in c(1:3, 5)) assign(paste0("component",i), tclVar("0"))
component4 <- tclVar("1")

test_input <- list(
  Cases = "J:\\department-files\\r-scripts\\tests\\system-level-tests\\examFiles\\output\\OphthC_Cases_20150515_examDetailsBeforeDiscussion.csv"
)

number_pass <- list("Cases" = tclVar("15"))
number_fail <- list("Cases" = tclVar("5"))

rbValue2 <- tclVar("Yes")
rbValue3 <- tclVar("No")
removedCases_rb <- tclVar("No")
