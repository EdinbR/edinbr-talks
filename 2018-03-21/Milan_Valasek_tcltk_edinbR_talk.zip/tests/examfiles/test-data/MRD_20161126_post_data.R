

# MRD 20161126 post discussion ----------------------------------------------------
# 4 MSA papers
# MRD Oral components

rbValue <- tclVar("Final")

for (i in c(2, 5)) assign(paste0("component",i), tclVar("1"))
for (i in c(1, 3, 4)) assign(paste0("component",i), tclVar("0"))

test_input <- list(
  MSA = c("J:\\department-files\\r-scripts\\tests\\system-level-tests\\examFiles\\output\\MRD_General_MSA_20161126_examDetailsBeforeDiscussion.csv",
          "J:\\department-files\\r-scripts\\tests\\system-level-tests\\examFiles\\output\\MRD_Endo_MSA_20161126_examDetailsBeforeDiscussion.csv",
          "J:\\department-files\\r-scripts\\tests\\system-level-tests\\examFiles\\output\\MRD_Perio_MSA_20161126_examDetailsBeforeDiscussion.csv",
          "J:\\department-files\\r-scripts\\tests\\system-level-tests\\examFiles\\output\\MRD_Prostho_MSA_20161126_examDetailsBeforeDiscussion.csv"),
  Oral_Viva = "J:\\department-files\\r-scripts\\tests\\system-level-tests\\examFiles\\output\\MRD_Oral_Viva_20161126_examDetailsBeforeDiscussion.csv"
)

number_pass <- list("MSA" = tclVar("21"),
                    "Oral_Viva" = tclVar("30"))
number_fail <- list("MSA" = tclVar("14"),
                    "Oral_Viva" = tclVar("5"))

rbValue2 <- tclVar("Yes")
rbValue3 <- tclVar("No")
removedCases_rb <- tclVar("Yes")
# mark 3rd case for removal
itemsCases <- list(tclVar("0"), tclVar("0"), tclVar("1"), tclVar("0"))
