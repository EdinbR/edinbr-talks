
# DMIM before discussion --------------------------------------------------
# all components
# 1 SBA paper
# 2 MSA papers
# domain-based OSCES
# domain based Ceses - double marked


# win 1 --------------------------------------------------------------------

rbValue <- tclVar("Preliminary")


# win 2 -------------------------------------------------------------------

specialty <- "Disc3Spec2"
mock_date <- "20110111"
checked_components <- c(1, 1, 1, 1, 0)
for (i in 1:length(comps_test))
  assign(paste0("component", i), tclVar(checked_components[i]))
exam_date <- tclVar(mock_date)
n_cand = tclVar("20")

# exempts ------------------------------------------------------------------


n_exemptSBA = tclVar("")
n_exemptMSA = tclVar("")
n_exemptOSCE = tclVar("")
n_exemptCases = tclVar("")


#  win 4 ------------------------------------------------------------------

default_dom_OSCE <- tclVar("4")
rbValue4 <- tclVar("Domain-based")

default_dom_Cases <- tclVar("4")
number_Cases <- tclVar("5")
rbValue5 <- tclVar("Mark/Domain")


# win 5 -------------------------------------------------------------------

mock_domainsOSCE <- LETTERS[1:4]
mock_check_domsOSCE <- matrix(c(1, 1, 1, 1,
                                1, 0, 1, 1,
                                1, 1, 0, 1,
                                1, 1, 1, 0,
                                0, 1, 1, 1,
                                1, 0, 1, 0,
                                1, 0, 0, 1),
                              ncol = length(mock_domainsOSCE), byrow = T)
for (i in 1:length(mock_domainsOSCE)) {
  assign(paste0("domain_nameOSCE", i), tclVar(mock_domainsOSCE[i]))
  for (j in 1:dim(mock_check_domsOSCE)[1])
    assign(paste("domainOSCE", j, i, sep = "_"),
           tclVar(as.character(mock_check_domsOSCE[j, i]))) #look out: j, i, not i, j
}
rb_markOSCE <- tclVar("Single")


# win 6 -------------------------------------------------------------------

mock_namesCases <- c("Case 01", "Case 02", "Case 03", "Case 04", "Case 05")
for (i in 1:length(mock_namesCases))
  assign(paste0("case_name", i), tclVar(mock_namesCases))

standard <- tclVar("2.75")
rb_markCases <- tclVar("Double")
mock_dom_nameCases <- LETTERS[1:4]
mock_domsCases <- matrix(c(1, 1, 1, 1,
                           0, 1, 1, 1,
                           1, 0, 1, 1,
                           1, 1, 0, 1,
                           1, 1, 1, 0),
                         ncol = length(mock_dom_nameCases), byrow = T)
for (i in 1:length(mock_namesCases)) {
  assign(paste0("case_name", i), tclVar(mock_namesCases[i]))
  for (j in 1:length(mock_dom_nameCases))
    assign(paste("domainCases",i, j, sep = "_"), tclVar(mock_domsCases[i, j]))
}
for (i in 1:length(mock_dom_nameCases)) {
  assign(paste0("domain_nameCases", i), tclVar(mock_dom_nameCases[i]))
}

