

# TriColPaeDent post discussion ----------------------------------------------------
# SBA paper
# Documented & Simulated Cases
# Clinical Governance

rbValue <- tclVar("Final")

for (i in c(1, 5)) assign(paste0("component",i), tclVar("1"))
for (i in 2:4) assign(paste0("component",i), tclVar("0"))

test_input <- list(
  SBA_EMI = "J:\\department-files\\r-scripts\\tests\\system-level-tests\\examFiles\\output\\TriColPaeDent_SBA_EMI_20170425_examDetailsBeforeDiscussion.csv",
  SimCases = "J:\\department-files\\r-scripts\\tests\\system-level-tests\\examFiles\\output\\TriColPaeDent_SimCases_20170425_examDetailsBeforeDiscussion.csv",
  DocCases = "J:\\department-files\\r-scripts\\tests\\system-level-tests\\examFiles\\output\\TriColPaeDent_DocCases_20170425_examDetailsBeforeDiscussion.csv",
  ClinGov = "J:\\department-files\\r-scripts\\tests\\system-level-tests\\examFiles\\output\\TriColPaeDent_ClinGov_20170425_examDetailsBeforeDiscussion.csv"
)

number_pass <- list("SBA" = tclVar("21"),
                    "SimCases" = tclVar("16"),
                    "DocCases" = tclVar("20"),
                    "ClinGov" = tclVar("9"))
number_fail <- list("SBA" = tclVar("9"),
                    "SimCases" = tclVar("14"),
                    "DocCases" = tclVar("10"),
                    "ClinGov" = tclVar("21"))

rbValue1 <- tclVar("No")
rbValue2 <- tclVar("No")
rbValue3 <- tclVar("Yes")
test_remSBA <- c("20, 163")
removedCases_rb <- tclVar("Yes")
# mark 3rd case for removal
itemsCases <- list(tclVar("1"), tclVar("0"), tclVar("0"),
                   tclVar("0"), tclVar("0"), tclVar("0"))
