
# DipImplant before discussion --------------------------------------------------
# 2 SBA papers
# checklist OSCES


# win 1 --------------------------------------------------------------------

rbValue <- tclVar("Preliminary")


# win 2 -------------------------------------------------------------------

specialty <- "Disc1Spec2"
mock_date <- "20120212"
checked_components <- c(1, 1, 1, 1, 1)
for (i in 1:length(comps_test))
  assign(paste0("component", i), tclVar(checked_components[i]))
exam_date <- tclVar(mock_date)
n_cand = tclVar("20")

# SBA -------------------------------------------------------------------

n_SBA <- tclVar("178")
n_EMI <- tclVar("0")
n_exemptSBA = tclVar("2-4")


# MSA -------------------------------------------------------------------

n_exemptMSA <- tclVar("")


#  OSCE -----------------------------------------------------------------

default_dom_OSCE <- tclVar("None")
rbValue4 <- tclVar("Checklist")
n_exemptOSCE <- tclVar("5")

#  Orals & Cases --------------------------------------------------------
n_exemptCases <- tclVar("6,8")
n_exemptOral <- tclVar("")

