
# SEM Part 1 before discussion ---------------------------------------------
# 2 SBA papers
# checklist OSCES
# Orals/vivas


# win 1 -------------------------------------------------------------------

rbValue <- tclVar("Preliminary")


# win 2 -------------------------------------------------------------------

specialty <- "Disc4Spec1"
mock_date <- "20120212"
checked_components <- c(1, 0, 1, 0, 1)
for (i in 1:length(comps_test))
  assign(paste0("component", i), tclVar(checked_components[i]))
exam_date <- tclVar(mock_date)
n_cand = tclVar("33")

# SBA -------------------------------------------------------------------

n_SBA <- tclVar("178")
n_EMI <- tclVar("0")
n_exemptSBA = tclVar("")


#  OSCE -----------------------------------------------------------------

default_dom_OSCE <- tclVar("None")
rbValue4 <- tclVar("Checklist")
n_exemptOSCE <- tclVar("")

#  Orals ----------------------------------------------------------------
n_exemptOral <- tclVar("24-29")
n_Orals <- tclVar("4")
oral_name1 <- tclVar("Oral 1")
oral_name2 <- tclVar("Oral 2")
oral_name3 <- tclVar("Oral 3")
oral_name4 <- tclVar("Oral 4")