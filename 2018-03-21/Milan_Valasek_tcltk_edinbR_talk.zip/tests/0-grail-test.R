
library(testthat)
library(tcltk)

data_path <- "C:/Users/Milan/Desktop/edinbR/tests/test-data/"

test.run <- T

extract_code <- function(script, source.path = source_path) {
  x <- readLines(paste0(source.path, script))
  
  begin_omit <- grep("### test not run", x)
  end_omit <- grep("### run not test", x)
  omit <- paste0(begin_omit, ":", end_omit, collapse = ", ")
  expr <- ifelse(length(begin_omit) == 0, "x", paste0("x[-c(", omit, ")]"))
  return(eval(parse(text = expr)))
}

# read in and modify edinbR.R
test_script <- extract_code(
  "edinbR.R",
  "C:/Users/Milan/Desktop/edinbR/")
test_script <- gsub("source\\((\\\"q\\d\\.R\\\").*",
                    "eval(parse(text = extract_code(\\1)))", test_script)

# read in mock data
data_files <- grep("_data.R", list.files(data_path), value = T)

for (d_file in data_files) {
  
  cat(paste("\n\n############### Testing", d_file,
            "###############\n"))
  # read in pre data
  source(paste0(data_path, d_file))
  
  # run the app
  eval(parse(text = test_script))
  
  # test
  test_file(gsub("test-data/", "1-test1.R", data_path))
  # tidy up
  rm(list = setdiff(ls(), c("data_path", "data_files", "d_file",
                            "extract_code", "test.run", "test_script")))
}
