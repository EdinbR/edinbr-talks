 
# Sir Robin
# Holy Grail
# Nineveh


# win 1 --------------------------------------------------------------------

entry.name <- tclVar("Sir Robin")

# win 2 -------------------------------------------------------------------

rb_q2 <- tclVar("seek the Holy Grail")

# win 3 -------------------------------------------------------------------

rb_q3 <- tclVar("1")

# reference

out_ref <- list(q1 = list(question = "What... is your name?",
                          answer = "Sir Robin"),
                q2 = list(question = "What... is your quest?",
                          answer = "seek the Holy Grail"),
                q3 = list(question = "What... is the capital of Assyria?",
                          answer = "Nineveh"))
