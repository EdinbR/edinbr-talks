
context(paste("Testing", d_file, "examDetailsAfterDiscussion files"))

exam_details <- gsub("Before", "After", exam_details)

test_that("examDetailsAfterDiscussion files are correct", {
  for (f in exam_details) {
    x <- read.csv(paste0(sub("test-data", "output", data_path), f))
    ref <- read.csv(paste0(sub("test-data", "ref-files", data_path), f))
    expect_equal(x, ref, label = f)
  }
})

context(paste("Testing additional", d_file, "files"))

aux_files <- grep("MSA|OSCE", exam_details, value = T)
if (length(aux_files) > 0) {
  aux_msa <- gsub("examDetailsAfterDiscussion", "maxPerQuestion",
                  grep("MSA", aux_files, value = T))
  aux_files <- gsub("examDetailsAfterDiscussion", "stationSummaries",
                    grep("OSCE", aux_files, value = T))
  aux_files <- c(aux_msa, aux_files)
  test_that("additional files are correct", {
    for (f in aux_files) {
      x <- read.csv(paste0(sub("test-data", "output", data_path), f))
      ref <- read.csv(paste0(sub("test-data", "ref-files", data_path), f))
      expect_equal(x, ref, label = f)
    }
  })
}
