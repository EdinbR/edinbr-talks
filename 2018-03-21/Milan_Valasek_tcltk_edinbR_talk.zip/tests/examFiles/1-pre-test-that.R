
context(paste("Testing", d_file, "Excel files"))

### in case the below doesn't work to extract all components
# files <- list.files()[grep(gsub("(_\\d{8})", "_.*?\\1", d_file), list.files())]
# unique(gsub(paste0(prefix.spec, "_(.*)_\\d{8}.*"), "\\1", files))

used_comps <- names(out)[
  names(out) %in% gsub("/.*", "", components) & names(out) != "SBA"]
setwd("~/department-files/r-scripts/tests/system-level-tests/examFiles/output/")

for (component in used_comps) {
  test_that("Excel file header and 1st column are correct", {
    if (component == "MSA") {
      for (paper in seq_along(out$MSA$name)) {
        if (out$MSA$name[paper] %in% c("MSA", "Selected response")) {
          df <- as.data.frame(read_excel(paste0(out$MSA$file, ".xlsx"), 1))
        } else {
          temp_file <- paste0(
            sub("MSA", paste0(
              gsub(" ", "_", out$MSA$name[paper]),
              "_MSA"),
              out$MSA$file), ".xlsx")
          df <- as.data.frame(read_excel(temp_file, 1))
        }
        header <- c(
          "Item number", setdiff(1:out$MSA$n_items[paper],
                                 out$MSA$removed[paper]),
          "Total")
        expect_equal(names(df[1]), out$MSA$name[paper],
                     label = paste("MSA paper", paper, "cell A1 is correct"))
        expect_true(all(df[1, ] == header), label = paste(
          "MSA paper", paper, "header is correct"))
        expect_true(all(gsub("Cand ", "", grep("Cand", df[[1]], value = T)) ==
                          rep(msa_cands[[paper]], each = 2)),
                    label = paste("MSA paper", paper, "candidate numbers are correct"))
        expect_equal(df[c(nrow(df) - 1, nrow(df)), 1],
                     c("Examiner 1", "Examiner 2"), label = paste(
                       "MSA paper", paper, "file has examiner rows"))
      }
    } else {
      sheet <- excel_sheets(paste0(out[[component]]$file, ".xlsx"))
      for (s in seq_along(sheet)) {
        df <- as.data.frame(read_excel(paste0(out[[component]]$file, ".xlsx"), s))
        if (prefix.spec == "DipImplant" && component == "Oral") {
          expect_equal(names(df[!is.na(names(df)) & nchar(names(df)) > 0]),
                      c("Case 1", "Case 2"), label = paste(
            component, "sheet", s, ", Row 1 is correct"))
        } else if (prefix.spec == "TriColPaeDent" &&
                   component %in% c("DocCases", "SimCases", "ClinGov")) {
          a1 <- if (component == "DocCases") {
            "Documented Cases"
          } else if (component == "SimCases") {
            "Simulated Cases"
          } else "Clinical Governance"
          expect_true(names(df)[1] == a1, label = paste(
            component, "sheet", s, "cell A1 is correct"))
        } else if (prefix.spec == "MRD" && component == "Oral") {
          expect_true(names(df)[1] == "Oral Components", label = paste(
            component, "sheet", s, "cell A1 is correct"))
        } else if (prefix.spec == "MOrth" && component %in% c("Diag", "Orals_Comms")) {
          expect_true(names(df)[1] == ifelse(
            component == "Diag", "Diagnostics",
            ifelse(s == 1, "Orals", "Comms")),
            label = paste(component, "sheet", s, "cell A1 is correct"))
        } else {
          if (component == "Oral") {
            expect_equal(names(df)[1], "Orals/Vivas",
                         label = paste(component, "sheet",
                                       s, "cell A1 is correct"))
          } else if (!"Mark/Case" %in% unlist(out[[component]])) {
            expect_equal(names(df)[1], out[[component]]$name[s],
                         label = paste(component, "sheet",
                                       s, "cell A1 is correct"))
          } else expect_true(names(df)[1] == "Cases", label = paste(
            component, "sheet", s, "cell A1 is correct"))
        }
        
        if (prefix.spec == "DipImplant" && component != "OSCE") {
          if (component == "Cases") {
            temp_dom <- out[[component]]$which_domain[[s]]
            header <- c(
              "Name of marking domain", out[[component]]$domains[temp_dom],
              "Total", "Examiner Number/Name")
          } else {
            temp_dom <- out[[component]]$which_domain[[s]]
            header <- c("Name of marking domain",
                        rep(c(out[[component]]$domains[temp_dom],
                              "Score", "Examiner Number/Name"), 2),
                        "Total x 2")
          }
        } else if (prefix.spec == "MOrth" && component %in% c("Diag", "Orals_Comms")) {
          if (component == "Orals_Comms") {
            temp_dom <- out[[component]]$which_domain[[s]]
            header <- c(
              NA, out[[component]]$domains[temp_dom], "Total", "Examiner Number/Name")
          } else header <- c(
            NA, out[[component]]$name, "Total", "Examiner Number/Name")
        } else if ("domains" %in% names(out[[component]])) {
          temp_dom <- out[[component]]$which_domain[[s]]
          header <- c(
            "Name of marking domain", out[[component]]$domains[temp_dom],
            "Global Evaluation 1-4", "Total", "Examiner Number/Name")
        } else if (component == "OSCE") {
          header <- c(
            "Item number", 1:out[[component]]$n_items[s],
            "Global Evaluation 1-4", "Total", "Examiner Number/Name")
        } else if (component == "Oral") {
          header <- c(
          "Oral/Viva name", out[[component]]$name, "Total", "Examiner Number/Name")
        } else header <- c(
          "Case name", out[[component]]$name, "Total", "Examiner Number/Name")
        
        if (component %in% c("ClinGov", "Diag", "Orals_Comms"))
          header[1] <- df[1, 1] <- ""
        expect_true(all(df[1, ] == header), label = paste(
          component, "sheet", s, "header is correct"))
        multiple <- ifelse(out[[component]]$mark == "Single", 1, 2)
        if (prefix.spec == "MRD") {
          expect_true(all(
            gsub("Cand ", "", grep("Cand", df[[1]], value = T)) ==
              c("Endodontics Candidates", rep(msa_cands$Endo, each = 2),
                "Periodontics Candidates", rep(msa_cands$Perio, each = 2),
                "Prosthodontics Candidates", rep(msa_cands$Prostho, each = 2))),
            label = paste(component, "sheet", s,
                          "candidate numbers are correct"))
        } else
          expect_true(all(
            gsub("Cand ", "", grep("Cand", df[[1]], value = T)) ==
              rep(1:as.numeric(out[[component]]$n_candidates), each = multiple)),
            label = paste(component, "sheet", s,
                          "candidate numbers are correct"))
      }
    }
  })
  
  test_that("Excel formulae are correct", {
    formula <- eval(parse(text = paste0("formula_", component)))
    if (prefix.spec == "DipImplant" && component == "Cases") {
      expect_true(all(sapply(formula, length) == out[[component]]$n_candidates * 2),
                  label = paste(component, "There are 2 formulae per candidate"))
    } else
    # check n of formulae matches n of candidates
    expect_true(all(sapply(formula, length) == out[[component]]$n_candidates),
                label = paste(component, "There is 1 formula per candidate"))
    
    for (q in seq_along(formula)) {
      ## extract row numbers from formulae
      ## the * is there for doubled totals (... * 2)
      x <- strsplit(gsub("[^0-9:,\\*]", "", formula[[q]]), ":|,|\\*")
      ## get rid of the 2 in ... * 2
      if (all(lapply(x, length) %in% c(3,5)))
        x <- lapply(x, function(x) x[1:(length(x) - 1)])
      
      if (component == "MSA") {
        r <- q
        multiple <- 2
        test_formula <- "AVERAGE(SUM(), SUM())"
      } else if (prefix.spec == "DipImplant" &&
                 component %in% c("Cases", "Oral")) {
        r <- 1
        multiple <- 2
        if (component == "Cases") {
          multiple <- 1
          test_formula <- "SUM()"
        } else
          ## , included because of the way formulae are extracted below
          test_formula <- "SUM(,) * 2"
      } else if (prefix.spec == "MOrth" &&
                 component %in% c("Cases", "Diag", "Orals_Comms")) {
        r <- 1
        multiple <- 2
        test_formula <- ifelse(component == "Cases", "SUM() * 2", "SUM()")
      } else if ("Domain-based" %in% unlist(out[[component]])) {
        r <- 1
        multiple <- ifelse(out[[component]]$mark == "Single", 1, 2)
        test_formula <- ifelse(out[[component]]$mark == "Single",
                               "AVERAGE()",
                               "AVERAGE(SUM(), SUM())")
      } else if ("Checklist" %in% unlist(out[[component]])) {
        r <- 1
        multiple <- 1
        test_formula <- "SUM()"
      } else if ("Mark/Case" %in% unlist(out[[component]])) {
        r <- 1
        multiple <- 2
        test_formula <- "SUM()"
      } else if ("Mark/Domain" %in% unlist(out[[component]])) {
        r <- 1
        multiple <- ifelse(out[[component]]$mark == "Single", 1, 2)
        test_formula <- "AVERAGE()"
      } else if ("Mark/Oral" %in% unlist(out[[component]])) {
        r <- 1
        multiple <- ifelse(out[[component]]$mark == "Single", 1, 2)
        test_formula <- "SUM()"
      }
      # single/double-marked
      expect_true(all(sapply(x, function(x) length(unique(x))) == multiple),
                  label = paste(component, "sheet/paper", q,
                                "formulae are correctly single/double-marked"))
      ## change multiple to pass the test below
      if (prefix.spec == "DipImplant" && component == "Cases") multiple <- 2
      # check row numbers in formulae are consecutive
      if (prefix.spec == "MRD" && component != "MSA") {
        expect_equal(as.vector(sapply(x, function(x) as.numeric(unique(x)))),
                     which(!is.na(as.numeric(cand))) + 2,
                     label = paste("row numbers in", component, "sheet/paper", q,
                                   "formulae are consecutive"))
      } else
        expect_equal(as.vector(sapply(x, function(x) as.numeric(unique(x)))),
                     3:(as.numeric(out[[component]]$n_candidates[r]) * multiple + 2),
                     label = paste("row numbers in", component, "sheet/paper", q,
                                   "formulae are consecutive"))
      
      if (prefix.spec == "DipImplant" && component == "Oral") {
        # check formulae start with column F
        expect_true(all(gsub(".*?\\$(.)\\$.*", "\\1", formula[[q]]) == "F"),
                    label = paste(component, "sheet/paper", q,
                                  "formulae all start with the right column"))
        # check formulae span the right n of columns
        expect_true(all(gsub(".*:\\$(.)\\$.*", "\\1", formula[[q]]) == "L"),
                    label = paste(component, "sheet/paper", q,
                                  "formulae span the right number of columns"))
      } else {
        # check formulae start with column B
        expect_true(all(gsub(".*?\\$(.)\\$.*", "\\1", formula[[q]]) == "B"),
                    label = paste(component, "sheet/paper", q,
                                  "formulae all start with B column"))
        # check formulae span the right n of columns
        expect_true(all(gsub(".*:\\$(.)\\$.*", "\\1", formula[[q]]) ==
                          LETTERS[out[[component]]$n_items[q] -
                                    ifelse(out[[component]]$removed[q] == "",
                                           0, length(out[[component]]$removed[q])) + 1]),
                    label = paste(
                      component, "sheet/paper", q,
                      "formulae span the right number of columns"))
      }
      # check operations in formulae are correct for given exam format
      expect_true(all(gsub("\\$[[:alpha:]]+\\$\\d+:\\$[[:alpha:]]+\\$\\d+",
                           "", formula[[q]]) == test_formula),
                  label = paste(component, "sheet/paper", q,
                                "formulae operations are correct"))
    }
  })
}

context(paste("Testing", d_file, "examDetailsBeforeDiscussion files"))

test_that("examDetailsBeforeDiscussion files are correct", {
  for (f in exam_details[exam_details %in% list.files()]) {
    x <- read.csv(paste0(sub("test-data", "output", data_path), f))
    ref <- read.csv(paste0(sub("test-data", "ref-files", data_path), f))
    expect_equal(x, ref, label = f)
  }
})

