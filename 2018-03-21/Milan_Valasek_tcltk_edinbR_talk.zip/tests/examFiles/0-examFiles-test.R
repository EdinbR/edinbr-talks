
### runs bits of scripts that are only for testing
library(tcltk)
library(testthat)
library(readxl)
data_path <- "~/department-files/r-scripts/tests/system-level-tests/examFiles/test-data/"
ss_path <- "~/department-files/r-scripts/tests/system-level-tests/examFiles/test-data/"
setwd("~/department-files/r-scripts/tests/system-level-tests/examFiles/output/")
test.run <- T

extract_code <- function(script, source.path = source_path) {
  x <- readLines(paste0(source.path, script))
  
  begin_omit <- grep("### test not run", x)
  end_omit <- grep("### run not test", x)
  omit <- paste0(begin_omit, ":", end_omit, collapse = ", ")
  expr <- ifelse(length(begin_omit) == 0, "x", paste0("x[-c(", omit, ")]"))
  return(eval(parse(text = expr)))
}

# read in and modify examFiles.R
test_script <- extract_code(
  "examFiles.R",
  "~/department-files/r-scripts/staff-resources/examFiles/")
test_script <- gsub("source(paste0(source_path, ",
                    "eval(parse(text = extract_code(", test_script, fixed = T)
test_script <- gsub("\"), verbose = F", "\"))", test_script)

comps_test <- c("SBA/EMI", "MSA", "OSCE/OSPE", "Cases", "Oral/Viva")

# read in mock data
data_files <- grep("_data.R", list.files(data_path), value = T)

for (d_file in unique(gsub("_p[ro].*", "", data_files))) {
  
  cat(paste("\n\n############### Testing", d_file,
            "*BEFORE* discussion ###############\n"))
  # read in pre data
  source(paste0(data_path, d_file, "_pre_data.R"))
  
  # RUN PRE examFIles
  eval(parse(text = test_script))
  
  # RUN PRE TESTS
  exam_details <- paste0(
    grep("_examDetailsBefore", ls(), value = T), ".csv") # here b/c of ls() env
  test_file(sub("test-data/", "1-pre-test-that.R", data_path))
  
  # tidy up
  rm(list = setdiff(ls(), c("comps_test", "data_path", "data_files", "d_file",
                            "exam_details", "extract_code", "ss_path", "test.run",
                            "test_script")))
  
  cat(paste("\n############### Testing", d_file,
            "*AFTER* discussion ###############\n"))
  # read in post data
  source(paste0(data_path, d_file, "_post_data.R"))
  
  # RUN POST examFiles
  eval(parse(text = test_script))

  # RUN POST TESTS
  test_file(sub("test-data/", "2-post-test-that.R", data_path))
  
  # tidy up
  rm(list = setdiff(ls(), c("comps_test", "data_path", "data_files", "d_file",
                            "extract_code", "ss_path", "test.run",
                            "test_script")))
}

# cleans the output folder
# file.remove(list.files(getwd()))
