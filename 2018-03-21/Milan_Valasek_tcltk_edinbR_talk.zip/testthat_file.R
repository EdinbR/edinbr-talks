
context("error")
test_that("non-numeric x returns error", {
  expect_error(foo("bar"))
  expect_error(foo(list(1, 2)))
  expect_error(foo(3))
})
