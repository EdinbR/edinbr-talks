
tt1 <- tktoplevel()
tkwm.title(tt1, "Holy grail")

OnOK0 <- function()  {
  tkdestroy(tt1)
}

OK.but <- tkbutton(tt1, text = "Ask me the questions, bridge-keeper.\nI'm not afraid.", command = OnOK0)

tkgrid(tklabel(tt1,text="Stop!\n\nWho would cross the Bridge of Death\nmust answer me these questions three,\n'ere the other side he see"),
       columnspan = 4, padx = 10, pady = 10)

tkgrid(OK.but, columnspan = 4, pady = 10)
Sys.sleep(0.05)
if (test.run) OnOK0() else finalise.window(tt1)
