
### q3

if (q2_ans == "learn about unit testing") {
  question <- "What... is the difference between a unit test and a system test?"
  ans_opt <- c("It's complicated...",
               "I don't know that!")
} else {
  if (grepl("arthur", tolower(q1_ans))) {
    question <- "What... is the air-speed velocity of an unladen swallow?"
    ans_opt <- c("What do you mean? An African or European swallow",
                 "~11 mps")
  } else if (grepl("robin", tolower(q1_ans))) {
    question <- "What... is the capital of Assyria?"
    ans_opt <- c("Nineveh", "Assur")
  } else {
    question <- "What... is your favourite colour?"
    ans_opt <- c("Blue", "Yellow")
  }
}

tt3 <- tktoplevel()
tkwm.title(tt3, "Question Three")

rb1 <- tkradiobutton(tt3)
rb2 <- tkradiobutton(tt3)

### test not run
rb_q3 <- tclVar("0")
### run not test

tkconfigure(rb1, variable = rb_q3, value = 1)
tkconfigure(rb2, variable = rb_q3, value = 2)


OnOK0 <- function()  {
  q3_choice <- as.character(tclvalue(rb_q3))
  if (q3_choice == "0") {
    ok_message(title = "Error", icon = "error",
               message = paste(
                 "Please answer the question, noble knight!"))
  } else {
    tkdestroy(tt3)
    q3 <<- question
    q3_ans <<- ans_opt[as.numeric(q3_choice)]
  }
}

OK.but <- tkbutton(tt3, text = "Next", command = OnOK0)

tkgrid(tklabel(tt3, text = question),
       columnspan = 4, padx = 10, pady = 10)
tkgrid(tklabel(tt3, text = ans_opt[1]), rb1, padx = 10)
tkgrid(tklabel(tt3, text = ans_opt[2]), rb2, padx = 10)

tkgrid(OK.but, columnspan = 4, pady = 10)
Sys.sleep(0.05)
if (test.run) OnOK0() else finalise.window(tt3)
