
### tcltk: http://www.sciviews.org/recipes/tcltk/toc/

library(tcltk)

w1 <- tktoplevel()

# radio buttob
rb1 <- tkradiobutton(w1) # create rb
rb2 <- tkradiobutton(w1)
entry.rb <- tclVar("0") # define mapping variable
tkconfigure(rb1, variable = entry.rb, value = 1)
tkconfigure(rb2, variable = entry.rb, value = 2)

# text box
entry.name <- tclVar("")

# tickbox
tickbox1 <- tkcheckbutton(w1)
tickbox2 <- tkcheckbutton(w1)
tickbox3 <- tkcheckbutton(w1)

starter <- tclVar("0")
main <- tclVar("1")
pudding <- tclVar("0")

tkconfigure(tickbox1, variable = starter)
tkconfigure(tickbox2, variable = main)
tkconfigure(tickbox3, variable = pudding)

# what happens when you click OK
OnOK0 <- function() {
  tkdestroy(w1)
}

# OK button
OK.but <- tkbutton(w1, text = "OK", command = OnOK0)

# window layout
tkgrid(tklabel(w1, text = "Dinner"), columnspan = 4, padx = 10, pady = 10)

tkgrid(tklabel(w1, text = "Name"),
       tkentry(w1, width = "20", textvariable = entry.name),
       columnspan = 2, padx = 10, pady = 10)
tkgrid(tklabel(w1, text="Vegan"), rb1,
       tklabel(w1, text="Murderer"), rb2, pady = 10)
tkgrid(tklabel(w1, text = "Starter"), tickbox1, columnspan = 2)
tkgrid(tklabel(w1, text = "Main course"), tickbox2, columnspan = 2)
tkgrid(tklabel(w1, text = "Pudding"), tickbox3, columnspan = 2)

tkgrid(OK.but, columnspan = 4, pady = 10)
