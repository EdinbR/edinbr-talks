
### q2
tt3 <- tktoplevel()
tkwm.title(tt3, "Question Three")

rb1 <- tkradiobutton(tt3)
rb2 <- tkradiobutton(tt3)
question <- "What... is your quest?"

### test not run
rb_q2 <- tclVar("0")
### run not test

tkconfigure(rb1, variable = rb_q2, value = "seek the Holy Grail")
tkconfigure(rb2, variable = rb_q2, value = "learn about unit testing")

OnOK0 <- function()  {
  quest_choice <- as.character(tclvalue(rb_q2))
  if (quest_choice == "0") {
    ok_message(title = "Error", icon = "error",
               message = paste(
                 "Please state your quest, noble knight!"))
  } else {
    tkdestroy(tt3)
    q2 <<- question
    q2_ans <<- quest_choice
  }
}

OK.but <- tkbutton(tt3, text = "Next", command = OnOK0)

tkgrid(tklabel(tt3, text = question),
       columnspan = 4, padx = 10, pady = 10)
tkgrid(tklabel(tt3, text="To seek the Holy Grail"), rb1)
tkgrid(tklabel(tt3, text="To learn about unit testing"), rb2)

tkgrid(OK.but, columnspan = 4, pady = 10)
Sys.sleep(0.05)
if (test.run) OnOK0() else finalise.window(tt3)
