
library(tcltk)

finalise.window <- function (x) {
  tkwm.protocol(x, "WM_DELETE_WINDOW", function() { ## when user attempts to close window
  quit <- ok_message(
    "Do you truly wish to give up on\nthe Quest for the Holy Grail, noble knight?",
    "", "yesno")
    if (quit == "yes") {
      tkdestroy(x)
      pass <<- FALSE
    }
  })
  tkfocus(x)
  tkwm.resizable(x, F, F)
  tcl("wm", "attributes", x, topmost=TRUE)
  tkwait.window(x) ## pause execution of script till window is closed
}

ok_message <- function(message, title = "", type = "ok", icon = "info") {
  tt0 <- tktoplevel()
  tkwm.withdraw(tt0)
  if (type == "yesno") {
    return(tclvalue(
      tkmessageBox(parent = tt0, type = type, title = title,
                   message = message, icon = icon))
    )
  } else {
    if (title == "Error")
      icon <- "error"
    else if (title == "Information missing")
      icon = "warning"
    else icon = "info"
    tkmessageBox(parent = tt0, type = "ok", title = title,
                 message = message, icon = icon)
  }
  tkdestroy(tt0)
}

### test not run
test.run <- F
### run not test

source_path <- "C:/Users/Milan/Desktop/edinbR/"
wd_orig <- getwd()
setwd(source_path)


pass <- TRUE ## every constituent script file can change value if needed
## (e.g., aborted by user, error...)

source("intro.R", verbose = F)

if (pass) {
  source("q1.R", verbose = F)
  if (pass) {
    source("q2.R", verbose = F)
    if (pass) {
      source("q3.R", verbose = F)
      if (pass) {
        output <- list(q1 = list(question = q1,
                                 answer = q1_ans),
                       q2 = list(question = q2,
                                 answer = q2_ans),
                       q3 = list(question = q3,
                                 answer = q3_ans))
      }
    }
  }
}
setwd(wd_orig) # restore original wd
### test not run
rm(list = setdiff(ls(), "output")) # tidy up
### run not test
