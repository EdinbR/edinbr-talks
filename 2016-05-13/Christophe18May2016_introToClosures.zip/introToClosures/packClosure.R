# Simple closure for manipulating a pack of cards
# usage:
# p <- Pack() # create a new pack p
# p$show() # show the state of the pack
# p$shuffle() # shuffle the pack
# p$pickN(3) # remove the top 3 cards of the pack and output them
# 
# q <- Pack() # create a new, independant pack.


Pack <- function(){
  cards <- c(as.character(1:10),"J", "Q", "K")
  cards <- c( sapply(c("H","D","S","C"), function(x) paste0(cards, x)) )
  
  list(
    show = function(){
      cat("\n", cards)
    },
    
    shuffle = function(){
      cards <<- sample(cards)  
    },
    
    pickN = function(n = 1){
      selection <- head(cards, n)
      cards <<- tail(cards, -n)
      selection
    }
    
  )
}
