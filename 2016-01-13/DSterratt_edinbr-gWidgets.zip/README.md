# Talk: gWidgets2, a GUI system for R

This is the [Rmarkdown](http://rmarkdown.rstudio.com/) source of the
[slides](http://htmlpreview.github.io/?https://raw.githubusercontent.com/davidcsterratt/edinbr-gWidgets/master/edinbr-gWidgets2-2016-01-20.html) and code examples for a
talk I gave on 20th January 2016 to the
[Edinburgh R User Group](http://edinbr.org/) on
[John Verzani's](http://wiener.math.csi.cuny.edu/verzani/)
[gWidgets2](https://cran.r-project.org/web/packages/gWidgets2/) and
[gWidgets2RGtk2](https://cran.r-project.org/web/packages/gWidgets2RGtk2/)
packages, which provide a GUI system for
[R](https://www.r-project.org/).
